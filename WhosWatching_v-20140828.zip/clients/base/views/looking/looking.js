({
    initalize: function(options)
    {
        this._super('initalize', [options]);

        this.on('render', function() {
            this.$el.popover();
        });
    }
})
