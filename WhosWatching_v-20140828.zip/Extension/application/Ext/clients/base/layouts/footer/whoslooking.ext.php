<?php
$viewdefs['base']['layout']['footer']['components'][] = array('view' => 'looking');
