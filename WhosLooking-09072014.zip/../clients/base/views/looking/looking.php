<?php
$viewdefs['base']['view']['looking'] = array();
