<?php
$js_groupings[] = $sugar_grp_sidecar = array_merge($sugar_grp_sidecar,
    array(
        'custom/include/javascript/socket.io.js' => 'include/javascript/sugar_sidecar.min.js',
    )
);
