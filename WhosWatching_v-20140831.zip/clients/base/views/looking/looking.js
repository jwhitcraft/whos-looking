({
    tagName: 'span',
    fieldTag: 'a',

    ioSocket: undefined,

    registered: false,

    user_html: '',

    initialize: function(options)
    {
        this._super('initialize', [options]);
        if(app.api.isAuthenticated()) {
            this.on('render', function() {
                this.$el.find('a').popover();
                if(app.user.has('id')) {
                    var user = {
                        id: app.user.get('id'),
                        name: app.user.get('full_name'),
                        image: app.user.get('picture')
                    },
                    page = {
                        'module': '',
                        'action': '',
                        'id' : ''
                    };
                    debugger;
                    this.ioSocket.emit('register', user);
                }
            });

            this.ioSocket = io.connect('http://localhost:5000');
            this.ioSocket.on('registered', _.bind(function() {
                this.registered = true;
            }, this));
            this.ioSocket.on('lookers', _.bind(function(data) {
                this.user_html = App.template.getView('looking.users')({users: _.toArray(data.users)});
                this.$el.find(this.fieldTag).data('content', this.user_html)
            }, this));

            app.on('app:view:change', function(name, attributes) {
                if (this.registered) {
                    console.log('look-at-apage', name, attributes);
                    var args = {
                        'module': attributes.module,
                        'action': name,
                        'id': attributes.modelId
                    }

                    this.ioSocket.emit('look-at-page', args);
                }
            }, this);
        } else {
            // we are not rendered, so listen to before('render') and stop it
            this.before('render', function() {
                return false;
            }, null, this);
        }
    },

    _dispose: function() {
        app.off('app:view:change', null, this);
        if(this.ioSocket) {
            this.ioSocket.disconnect();
            this.ioSocket = undefined;
        }
    }
})
